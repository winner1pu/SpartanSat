import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * SpartanSat website server.
 *
 * Serves the same static site (index.html + assets/) exactly as-is —
 * this just gives you a Java program to run it with.
 *
 * HOW TO RUN:
 *   1. Keep this file in the SAME folder as index.html and assets/
 *   2. Compile:  javac Main.java
 *   3. Run:      java Main
 *   4. Open:     http://localhost:8000
 */
public class Main {

    private static final int PORT = 8000;
    private static final String ROOT_DIR = "."; // folder containing index.html

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/", new StaticFileHandler());
        server.setExecutor(null);
        server.start();
        System.out.println("SpartanSat site running at http://localhost:" + PORT);
        System.out.println("Press Ctrl+C to stop.");
    }

    static class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String requestPath = exchange.getRequestURI().getPath();
            if (requestPath.equals("/") || requestPath.equals("/admin") || requestPath.equals("/admin/")) {
                requestPath = requestPath.startsWith("/admin") ? "/admin/index.html" : "/index.html";
            }

            File file = new File(ROOT_DIR, requestPath).getCanonicalFile();
            File rootDir = new File(ROOT_DIR).getCanonicalFile();

            // Prevent path traversal outside the site folder
            if (!file.getPath().startsWith(rootDir.getPath()) || !file.isFile()) {
                byte[] notFound = "404 Not Found".getBytes();
                exchange.sendResponseHeaders(404, notFound.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(notFound);
                }
                return;
            }

            String contentType = guessContentType(file.getName());
            exchange.getResponseHeaders().set("Content-Type", contentType);
            exchange.sendResponseHeaders(200, file.length());

            try (OutputStream os = exchange.getResponseBody();
                 FileInputStream fis = new FileInputStream(file)) {
                fis.transferTo(os);
            }
        }

        private String guessContentType(String fileName) {
            String lower = fileName.toLowerCase();
            if (lower.endsWith(".html")) return "text/html; charset=utf-8";
            if (lower.endsWith(".css")) return "text/css; charset=utf-8";
            if (lower.endsWith(".js")) return "application/javascript; charset=utf-8";
            if (lower.endsWith(".json")) return "application/json; charset=utf-8";
            if (lower.endsWith(".png")) return "image/png";
            if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
            if (lower.endsWith(".webp")) return "image/webp";
            if (lower.endsWith(".svg")) return "image/svg+xml";
            if (lower.endsWith(".ico")) return "image/x-icon";
            return "application/octet-stream";
        }
    }
}
