"""
SpartanSat website server.

Serves the same static site (index.html + assets/ + admin/) exactly as-is —
this just gives you a Python program to run it with. Uses only Python's
built-in standard library, no installs needed.

HOW TO RUN:
    1. Keep this file in the SAME folder as index.html and assets/
    2. Run:   python3 server.py
    3. Open:  http://localhost:8000
"""

import http.server
import socketserver
import os

PORT = 8000
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))


class SpartanSatHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT_DIR, **kwargs)

    def do_GET(self):
        # Resolve "/" -> "/index.html" and "/admin" or "/admin/" -> "/admin/index.html"
        if self.path == "/":
            self.path = "/index.html"
        elif self.path in ("/admin", "/admin/"):
            self.path = "/admin/index.html"
        return super().do_GET()

    def end_headers(self):
        # Basic no-cache during local development so edits show up on refresh
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()


def main():
    with socketserver.TCPServer(("", PORT), SpartanSatHandler) as httpd:
        print(f"SpartanSat site running at http://localhost:{PORT}")
        print("Press Ctrl+C to stop.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopped.")


if __name__ == "__main__":
    main()
